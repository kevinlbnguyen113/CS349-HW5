#!/bin/bash
cd /code;
npm i;
npm run start;
